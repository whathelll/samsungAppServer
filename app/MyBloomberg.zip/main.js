

$(function() {
	var widgetAPI = new Common.API.Widget();
	widgetAPI.sendReadyEvent();
});